package EJERCLASE;

public class PoRegistro {
    public static void main(String[] args) {
        Registro r1 = new Registro();
        System.out.println("╔═════════════════════════════════════════════════════════╗");

        r1.anotarDatos();
        System.out.println("╚═════════════════════════════════════════════════════════╝");

    }
}
