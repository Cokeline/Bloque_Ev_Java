package EJERCLASE;

import java.util.Scanner;
import java.util.Set;

public class Registro {
    //nombre - permanencia(que no pueda ser negativo) y salario
    new Scanner sc = new Scanner(System.in);
    private String nombre;
    private int permanencia;
    private int salario;
   // private static Scanner sc;


    /**
     * 
     */
     Registro(){

        this.nombre = nombre;
        this.permanencia = permanencia;
        this.salario = salario;

    }

    public static void anotarDatos(){

        System.out.println("Introduce el nombre del trabajador: ");
        setnombre(sc.nextLine());
        System.out.println("Introduce los años que lleva de permanencia: ");
        setpermanencia(sc.nextInt());
        System.out.println("Introduce el salario de este: ");
        setsalario(sc.nextInt());
    }

   

    public static int Antiguedad(int permanencia) {
        
        if (condition) {
            
        } else if (condition) {
            
        }else{
            
        }
        return permanencia;
    }
    
    public static void MostrarDatos(String nombre, int permanencia, int salario) {

        System.out.println(String.format("\n\t - NOMBRE: ",getnombre(nombre)));
        System.out.println("\n\t - PERMANENCIA: ");
        System.out.println("\n\t - SALARIO: ");

    }
    
    public static String getnombre(String nombre){

        return nombre;

    }
    
    public static int getpermanencia(int permanencia){

        return permanencia;

    }

    public static int getsalario(int salario){

        return salario;

    }

    public  void setnombre(String nombre){

        this.nombre = nombre;

    }

    public void setpermanencia(int permanencia){

        this.permanencia = permanencia;

    }
   
    public void setsalario(int salario){

        this.salario = salario;

    }


}
